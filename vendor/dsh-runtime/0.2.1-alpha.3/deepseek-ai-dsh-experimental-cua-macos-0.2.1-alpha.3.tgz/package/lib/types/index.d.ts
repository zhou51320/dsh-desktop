import type { Context } from '@deepseek-ai/cordis';
import { CuaConfig } from '@deepseek-ai/dsh-cua';
export { GUIDANCE } from './guidance.ts';
/** Loader plugin identity. */
export declare const name = "experimental-cua-macos";
/** Services required by the shared CUA executor and the native launcher. */
export declare const inject: string[];
/** Native preparation, operation bounds, and profile-local application grants. */
export type Config = CuaConfig;
/** Validate the shared configuration before preparing the macOS helper. */
export declare const Config: typeof CuaConfig;
/**
 * Mount logged native operations with separate Agent connections to the shared helper.
 * @param ctx - Host context with computer-use, subprocess and tool services.
 * @param config - Validated native preparation and operation bounds.
 * @returns Completion after native preparation and tool registration.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map