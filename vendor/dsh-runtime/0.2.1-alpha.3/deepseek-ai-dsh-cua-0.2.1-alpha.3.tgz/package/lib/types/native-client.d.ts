import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
import type { ToolExecution } from '@deepseek-ai/dsh-tools';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import type { Readable, Writable } from 'node:stream';
/** Native refusal or transport failure with a stable machine-readable code. */
export declare class NativeError extends Error {
    readonly code: string;
    /**
     * @param code - Native error code or a transport-owned NATIVE_* code.
     * @param message - Actionable diagnostic, without its code prefix.
     * @param options - Original failure when available.
     */
    constructor(code: string, message: string, options?: ErrorOptions);
}
/** Resolved helper executable and bounded process/response configuration. */
export interface NativeClientConfig {
    helperPath: string;
    cwd: string;
    timeoutMs: number;
    connectTimeoutMs: number;
    screenshotTimeoutMs: number;
    axTimeoutMs: number;
    maxRequestBytes: number;
    maxResponseBytes: number;
    graceMs: number;
    textEventIntervalMs: number;
}
/** One Agent's ordered connection to native operations and cleanup acknowledgement. */
export interface NativeChannel {
    readonly stdin: Writable;
    readonly stdout: Readable;
    readonly done: Promise<void>;
    /** Stop writes and release this connection's native state. */
    close(): void;
    /** @returns Completion after the connection and its owned startup processes close. */
    waitForClose(): Promise<void>;
}
/**
 * Open the platform connection with the configured resource bounds.
 * @param owner - Managed subprocess provider for startup and cleanup.
 * @param config - Executable, operation limits, and deadlines.
 * @returns Agent-owned native byte stream and its cleanup acknowledgement.
 */
export type NativeChannelFactory = (owner: {
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
}, config: NativeClientConfig) => NativeChannel;
/** One Agent owns this connection and its native handles; other Agents use independent connections. */
export declare class NativeClient {
    private readonly reportDiagnostic?;
    private readonly handle;
    private readonly config;
    private readonly chunks;
    private bufferedBytes;
    private failure;
    private disposal;
    private diagnostics;
    private diagnosticBytes;
    private discardedDiagnostics;
    private active;
    /**
     * @param owner - Managed subprocess provider.
     * @param config - Executable, transport bounds and deadlines.
     * @param createChannel - Platform-owned connection and process lifecycle.
     * @param reportDiagnostic - Optional Host diagnostic sink; never receives captured content.
     */
    constructor(owner: {
        subprocess: Pick<SubprocessRuntime, 'spawn'>;
    }, config: NativeClientConfig, createChannel: NativeChannelFactory, reportDiagnostic?: ((message: string) => void) | undefined);
    /**
     * Send one operation. Native refusals preserve this connection; transport failures invalidate its handles.
     * @param method - Helper operation name.
     * @param params - JSON operation parameters.
     * @param signal - Cancellation stops this request; the connection survives when native cleanup acknowledges it.
     * @param callId - Logged tool invocation ID, when this request belongs to a tool execution.
     * @returns The validated helper result, after failure cleanup when needed.
     */
    request(method: string, params: Record<string, JsonValue>, signal: AbortSignal, callId?: ToolExecution['callId']): Promise<JsonValue>;
    private screenshotDiagnostics;
    private retainDiagnostic;
    private diagnostic;
    /** Whether this Agent's connection has lost its retained native state. */
    get disposed(): boolean;
    /** Invalidate this Agent's handles and close its connection; await dispose for native cleanup. */
    invalidate(): void;
    /** Stop this Agent's pending work and await its native connection cleanup. */
    dispose(): Promise<void>;
    private fail;
    private receive;
    private receiveFrame;
}
//# sourceMappingURL=native-client.d.ts.map