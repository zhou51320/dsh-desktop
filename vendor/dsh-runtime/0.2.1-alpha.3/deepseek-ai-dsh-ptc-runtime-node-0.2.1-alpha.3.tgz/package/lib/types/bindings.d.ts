import type { PtcBindingFunction, PtcBindingNamespace, PtcJsonValue, PtcRunRequest } from '@deepseek-ai/dsh-ptc-runtime';
import type { ReplyMessage } from './protocol.ts';
/**
 * Reject unusable namespaces before starting a process.
 * @param request - Host-owned binding declarations.
 * @returns Namespaces keyed by their declared global.
 */
export declare function validateBindings(request: PtcRunRequest): Map<string, PtcBindingNamespace>;
/**
 * Invoke a host binding and encode its lossless result or bounded-channel rejection.
 * @param id - Program-issued correlation identifier.
 * @param binding - Current evaluation's declared function, absent if it was removed.
 * @param args - Validated JSON arguments detached from the program.
 * @returns A reply suitable for the runtime's bounded control channel.
 */
export declare function replyToBinding(id: number, binding: PtcBindingFunction | undefined, args: PtcJsonValue): Promise<ReplyMessage>;
//# sourceMappingURL=bindings.d.ts.map