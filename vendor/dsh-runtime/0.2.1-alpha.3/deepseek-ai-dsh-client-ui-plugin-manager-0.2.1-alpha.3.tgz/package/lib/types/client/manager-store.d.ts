import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { BundleInfo, IncompatiblePlugin, ManagementError, PluginEntryId, PluginInfo, PluginInspectProblem, PluginInstallFailureKind, PluginInstallLogChunk, PluginInstallProgress, PluginInstallRequestId, PluginRegistries, PluginSpecInspection, ReadOnlyReason, Registry, RestartReason } from '@deepseek-ai/dsh-api-remotes/client';
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { LocalizedText, PluginLocalizedMeta } from '@deepseek-ai/dsh-package-manifest';
import type { SettingsDescribeFace, ConfigForms } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { ConfigLedger } from './config-ledger.ts';
/** The action a failed notice names. */
export type FailedAction = 'enable' | 'disable' | 'uninstall' | 'rowEnable' | 'rowDisable';
/** What the last action left to say, shown as a toast; `seq` tells one showing from the next. */
export type ManagerNotice = {
    readonly kind: 'restart';
    readonly packageName: string;
    readonly reason: RestartReason | undefined;
    readonly seq: number;
} | {
    readonly kind: 'overridden';
    readonly packageName: string;
    readonly seq: number;
} | {
    readonly kind: 'cancelled';
    readonly seq: number;
} | {
    readonly kind: 'refresh-failed';
    readonly seq: number;
} | {
    readonly kind: 'install';
    readonly outcome: 'done' | 'failed' | 'unconfirmed' | 'applying' | 'unknown';
    readonly seq: number;
} | {
    readonly kind: 'failed';
    /** What was being done when it failed. */
    readonly action: FailedAction;
    /** The Host's refusal, when the Host refused; absent when the transport failed. */
    readonly code?: ManagementError['code'];
    /** The Host's diagnostic or the transport's words, shown verbatim; empty when the code says it all. */
    readonly reason: string;
    /** The packages an `incompatible-version` refusal names. */
    readonly incompatible?: readonly IncompatiblePlugin[];
    readonly packageName?: string;
    readonly seq: number;
};
/** One row a bundle contributes, as the page lists it: the patch's declaration joined with its live entry. */
export interface PackageRow {
    /** The Loader entry carrying the row while the bundle is on; absent for a row of a bundle that is off. */
    readonly entryId?: PluginEntryId;
    /** The row id as the bundle declares it. */
    readonly rowId: string;
    /** The module the row names. */
    readonly moduleName: string;
    /** Local package display text and metadata diagnostics supplied by the Host. */
    readonly meta?: PluginLocalizedMeta;
    /** Whether the entry runs; false for a row without a live entry. */
    readonly enabled: boolean;
    /** The entry's fiber phase, null without a live fiber. */
    readonly phase: PluginInfo['fiberPhase'];
    /** Why the Host refuses to switch the row, when it does. */
    readonly readOnlyReason?: ReadOnlyReason;
}
/** One bundle as the page shows it: the Host's bundle joined with the entries its rows run as. */
export interface PackageView {
    readonly name: string;
    /** Official catalog identity is independent of installation and selection. */
    readonly official: boolean;
    /** Readable package location, separately from the profile dependency declaration. */
    readonly availability: BundleInfo['availability'];
    /** Host-derived exact version offered for installation or an explicit update. */
    readonly installTarget?: NonNullable<BundleInfo['installTarget']>;
    readonly version?: string;
    readonly description?: string;
    /** Local package display text and metadata diagnostics supplied by the Host. */
    readonly meta?: PluginLocalizedMeta;
    /** Whether the profile declares this dependency; availability separately describes its readable files. */
    readonly installed: boolean;
    /** Present for a profile dependency the installation does not also supply: the spec `pnpm add` accepts. */
    readonly source?: string;
    /** Whether the installation ships the bundle for the person to switch on: official, off until selected, never removable. */
    readonly optional: boolean;
    /** Whether the Host removes the bundle: a profile dependency, or a selection that neither the profile nor the installation holds. */
    readonly removable: boolean;
    /** Whether the bundle is in the profile's layer list. */
    readonly enabled: boolean;
    /** Why the Host refuses to switch the bundle off or remove it, when it does. */
    readonly readOnlyReason?: ReadOnlyReason;
    /** Why the Host cannot read the bundle, when it cannot. */
    readonly error?: ManagementError;
    readonly rows: readonly PackageRow[];
}
/** The typed spec as the Host read it, on the installing, installed, and failed screens. */
export type InstallSubject = Extract<PluginSpecInspection, {
    status: 'accepted';
}> & {
    readonly spec: string;
    /** Present for a catalog install or update: desired selection after installation. */
    readonly selection?: boolean;
    /** Save an exact dependency version through the generic installer. */
    readonly saveExact?: boolean;
};
/** The registry the person picked for an install: one the Host offers, or a typed URL. */
export type RegistryChoice = {
    readonly kind: 'offered';
    readonly registry: Registry;
} | {
    readonly kind: 'custom';
    readonly url: string;
};
/**
 * The registry a choice asks, as the Host's install plan compares registries: pnpm's own configuration stands for
 * the URL it names, once the Host has read it.
 * @param registry - the registry, null for the one pnpm's own configuration names.
 * @param resolved - the URL pnpm's own configuration names, null while the Host could not read it.
 * @returns the comparison key; a registry that does not parse compares as written.
 */
export declare function registryKey(registry: Registry, resolved: string | null): string;
/**
 * The registries the dialog offers: the Host's first, its fallbacks, and pnpm's own, each once. pnpm's own
 * configuration stands for the registry it names, so it never repeats a registry the Host already offers.
 * @param registries - what the Host configured, or null while unread.
 * @returns the registries in the order the dialog lists them.
 */
export declare function offeredRegistries(registries: PluginRegistries | null): Registry[];
/** Why the typed spec was refused before anything installed. */
export interface InstallInputError {
    /** The Host's refusal, or `shipped` for a listed bundle the installation supplies. */
    readonly problem: PluginInspectProblem | 'shipped';
    readonly reason: string;
    /** The registries the check asked, in order, when the refusal came from asking them. */
    readonly registries?: readonly Registry[];
}
/** One pnpm run of an install, as the dialog's terminal draws it. */
export interface InstallRun {
    readonly jobId: string;
    /** The command line the Host ran, space-joined. */
    readonly command: string;
    /** The directory the Host ran pnpm in: the profile directory. */
    readonly cwd: string;
    /** stdout and stderr interleaved as they arrived, pnpm's colour escapes included. */
    readonly output: string;
    /** pnpm's exit code once the run settled, null when it ended by a signal or never started; absent while it runs. */
    readonly exitCode?: number | null;
}
/**
 * Installation input, Host progress, and the final outcome. `unconfirmed` keeps
 * an unresolved request pending; `unknown` releases it after the Host reports
 * no active request and its original reply is lost. Neither means cancellation.
 * Closing any pending phase preserves its request and output for reopening.
 * Confirmed cancellation and returning from an outcome keep the spec for editing.
 */
export interface InstallState {
    readonly open: boolean;
    /** The package spec as typed. */
    readonly spec: string;
    /** The spec form was reopened after switching away from a failed GitHub address. */
    readonly mirrorRecovery?: boolean;
    /** The registries the Host configured, read when the dialog opens; null until the Host answered. */
    readonly registries: PluginRegistries | null;
    /** The registry this install asks first: the one last used, else the Host's first. */
    readonly registry: RegistryChoice;
    /** Whether the registry options are unfolded under the spec. */
    readonly registryOpen: boolean;
    /** Whether the typed registry was refused for not being an http(s) URL. */
    readonly registryError: boolean;
    /** The registries the Host asked for this install, in order, and how many it may ask; null before the run. */
    readonly attempts: {
        readonly registries: readonly Registry[];
        readonly total: number;
    } | null;
    readonly phase: 'idle' | 'checking' | 'starting' | 'running' | 'cancelling' | 'applying' | 'unconfirmed' | 'unknown' | 'done' | 'failed';
    /** Identifies this dialog's installation, including log and cancellation messages. */
    readonly requestId?: PluginInstallRequestId;
    /** Why the spec was refused before installing; shown under the field. */
    readonly inputError: InstallInputError | null;
    /** What the spec names, once the Host has read it. */
    readonly subject: InstallSubject | null;
    /** The pnpm runs of the open install, in the order they started. */
    readonly runs: readonly InstallRun[];
    /** Whether the run's command and output are unfolded, including after reopening. */
    readonly detailsOpen: boolean;
    /** The bundle the finished run added; ordinary installs await enablement, catalog operations carry their selection. */
    readonly installed: string | null;
    /** The version the finished run installed, when its manifest declares one; null otherwise. */
    readonly installedVersion: string | null;
    /** Whether the finished run's bundle waits for the next start to load. */
    readonly restartRequired: boolean;
    /** Why it waits, when the Host says. */
    readonly restartReason?: RestartReason;
    /**
     * The run's failure, once one settled the dialog: the Host's refusal
     * `code` with its diagnostic as `reason`, or the transport's words alone;
     * `kind` classifies a pnpm failure, and `pendingBuilds` names the packages
     * whose install scripts pnpm left undecided, offered for approval.
     * `uncertainty` distinguishes a lost installation reply, an unconfirmed
     * cancellation, and a cancellation awaiting the Host's acceptance of the run.
     */
    readonly failure: {
        readonly reason: string;
        readonly code?: ManagementError['code'];
        /** The packages an `incompatible-version` refusal names. */
        readonly incompatible?: readonly IncompatiblePlugin[];
        readonly kind?: PluginInstallFailureKind;
        /** What the last failed run could not reach, as the Host attributed it: the registry, or the spec's own host. */
        readonly failedAt?: 'registry' | 'spec-host';
        readonly pendingBuilds?: readonly string[];
        readonly uncertainty?: 'result' | 'cancellation' | 'acceptance';
    } | null;
    /** The packages whose install scripts the finished run was allowed to execute, saved for this profile. */
    readonly approvedBuilds: readonly string[];
    /** Enabling the newly installed bundle from the installed screen is crossing the wire. */
    readonly enabling: boolean;
}
/**
 * Whether an installation is still owned by the Host.
 * @param phase - the dialog's current installation phase.
 * @returns true while a Host result or a check for an active request is outstanding.
 */
export declare function isInstallPending(phase: InstallState['phase']): boolean;
/**
 * Offer the configured mainland mirror after a confirmed GitHub connection failure.
 * @param install - the installation and the Host's failure attribution.
 * @returns the offered entry that asks npmmirror, null when that entry is pnpm's own configuration, or undefined when
 * this recovery does not apply; test for undefined, because null is a valid entry.
 */
export declare function githubRecoveryRegistry(install: InstallState): Registry | undefined;
/**
 * Whether the install already asks npmmirror first, so switching to the offered mirror would not change the registry.
 * @param install - the installation and its registry choice.
 * @returns true when the chosen registry, offered or typed, compares as npmmirror.
 */
export declare function asksMirror(install: InstallState): boolean;
/** A destructive action waiting for the user's confirmation: a package's uninstall. */
export interface ConfirmState {
    readonly action: 'uninstall';
    readonly packageName: string;
}
/** What the tab renders. */
export interface PluginManagerState {
    /** `unavailable` when the Host runs without a managed profile; `error` keeps the last packages. */
    readonly status: 'idle' | 'loading' | 'ready' | 'error' | 'unavailable';
    /**
     * Manual refresh feedback: `refreshing` until reads settle and the 400 ms minimum elapses;
     * `failed` after a failed refresh without cached inventory; otherwise `idle`, including
     * cached refresh failures reported by toast. Background reads do not start the spinner.
     */
    readonly refreshStatus: 'idle' | 'refreshing' | 'failed';
    readonly packages: readonly PackageView[];
    /** Package names and row keys with an action crossing the wire. */
    readonly busy: readonly string[];
    readonly notice: ManagerNotice | null;
    readonly install: InstallState;
    readonly confirm: ConfirmState | null;
    /** The package the list scrolls to and marks, once an install enabled it. */
    readonly highlight: string | null;
}
/** The registration-side face the tab's slot entry injects. */
export interface PluginManagerFace {
    /** Resolve local package text in the current Client locale at render time. */
    resolveText: (text: LocalizedText) => string;
    /** Resolve a configuration form by the Host entry id. */
    configForm: ConfigForms['get'];
    hooks: {
        /** Shared accepted configuration values. */
        configurations: SettingsDescribeFace;
        /** Tab snapshot bound by the renderer as usePluginManager. */
        pluginManager: SnapshotStore<PluginManagerState>;
        /** The plugins carrying configuration, bound by the renderer as useConfigLedger. */
        configLedger: HostObservable<ConfigLedger>;
    };
    /** Read the Host once the tab first renders. */
    ensure: () => void;
    /** Read the Host again. */
    refresh: () => void;
    openInstall: () => void;
    /** Hide immediately, abort a check, or request cancellation while retaining the Host-owned installation. */
    closeInstall: () => void;
    editInstallSpec: (text: string) => void;
    /** Check the spec with the Host, then install it; from the failed screen, run it again. */
    runInstall: () => void;
    /** Fold or unfold the registry options under the spec. */
    toggleRegistryOptions: () => void;
    /** Pick the registry the install asks first, or type one. */
    chooseRegistry: (choice: RegistryChoice) => void;
    /** From the failed screen: back to the spec with the registry options unfolded. */
    changeRegistry: () => void;
    /** Return from a GitHub connection failure to an empty spec asking the offered mainland mirror, keeping a choice that asks it. */
    useGithubMirror: () => void;
    /** Allow the install scripts the failed run left pending, saved for this profile, and run the same spec again. */
    approveBuildsAndRetry: () => void;
    /** Leave the check or the failed screen for the spec, or ask the Host to stop the run and wait for its cleanup. */
    cancelInstall: () => void;
    /** Ask the Host for the result of an installation whose original reply was lost. */
    reconcileInstall: () => void;
    toggleInstallDetails: () => void;
    /** Enable the bundle the finished install added, then close the dialog and mark it in the list. */
    enableInstalled: () => void;
    /** Drop the list mark once it has been shown. */
    clearHighlight: () => void;
    /** Put a bundle into, or take it out of, the profile's layer list. */
    setEnabled: (packageName: string, enabled: boolean) => void;
    /** Remove an installed package and install the host's catalog version, selected as the package was. */
    update: (packageName: string) => void;
    /** Ask before removing a package from the profile. */
    uninstall: (packageName: string) => void;
    confirm: () => void;
    cancelConfirm: () => void;
    /** Switch one of a bundle's rows on or off in the profile's user layer. */
    setRowEnabled: (entryId: PluginEntryId, enabled: boolean) => void;
    dismissNotice: () => void;
}
/**
 * The key one row occupies in the busy list.
 * @param entryId - the row's Loader entry id.
 * @returns the busy key.
 */
export declare function rowKey(entryId: string): string;
/**
 * One bundle as the page shows it: its rows joined with the Host's entries.
 * @param bundle - the Host's bundle.
 * @param plugins - the Host's plugin entries.
 * @returns the package view.
 */
export declare function packageView(bundle: BundleInfo, plugins: readonly PluginInfo[]): PackageView;
/**
 * The order the list shows packages in: by the short name a person reads, so a
 * card stays put when its bundle is switched, whatever order the Host answers in.
 * @param packages - the Host's bundles as views.
 * @returns the views sorted by short name.
 */
export declare function sortPackages(packages: readonly PackageView[]): PackageView[];
/** Reads and mutates the profile's plugins through the `pluginManager` Remote. */
export declare class PluginManagerController {
    private readonly ctx;
    private readonly store;
    private inFlight;
    private rerun;
    private generation;
    private disposed;
    /** A successful managed-profile read remains usable even when it returned no bundles. */
    private hasCachedInventory;
    private pendingConfirm;
    /** Cancels the check the dialog has in flight. */
    private inspectAbort;
    private request;
    private noticeSeq;
    private analyticsAttempt;
    private registryRead;
    /** The registry last used from this browser, kept across dialogs and page loads; null until one was used. */
    private readonly registryMemory;
    /**
     * @param ctx - the tab plugin's context, whose `remote.pluginManager` and `remote.pluginInventory` namespaces answer.
     */
    constructor(ctx: ClientContext);
    /**
     * Read the tab's state.
     * @returns the current sync snapshot (stable reference until the next change).
     */
    getSnapshot(): PluginManagerState;
    /** Stop publishing and drop every late settlement. */
    dispose(): void;
    /**
     * Build the face the tab's slot registration injects.
     * @param configLedger - the projection of the plugins carrying configuration, bound beside the tab's own state.
     * @param resolveText - render-time package text resolution supplied by the locale service.
     * @returns the tab's snapshot sources and its actions.
     */
    inject(configLedger: HostObservable<ConfigLedger>, resolveText: PluginManagerFace['resolveText']): PluginManagerFace;
    /**
     * Follow the Host's cancellation window for this dialog's installation.
     * @param progress - a request id and phase received from the Host.
     */
    installProgress(progress: PluginInstallProgress): void;
    private currentRegistryRead;
    /** Read the registries the Host offers, for the dialog just opened; a refused read leaves pnpm's own and a typed one. */
    private readRegistries;
    /**
     * Fold a chunk belonging to this installation into its pnpm command.
     * A final chunk may arrive after the install answer and still updates an existing run.
     * @param chunk - the chunk the Host forwarded.
     */
    appendLog(chunk: PluginInstallLogChunk): void;
    /**
     * Read the bundles and the entries their rows run as. A call during an
     * in-flight read marks one rerun after it settles.
     * @returns settlement after this call's freshness is reflected.
     */
    load(): Promise<void>;
    /** Keep manual refresh feedback until its coalesced reads settle, without clearing cached cards. */
    private refresh;
    /** Publish refresh feedback only before disposal. */
    private settleRefresh;
    private read;
    private shouldRerun;
    private confirm;
    /** Drop the check in flight; its answer is ignored. */
    private abortInspect;
    /** Whether a settlement arrives too late to matter: the store is disposed, or the dialog moved on. */
    private gone;
    /** Reuse the install dialog with an exact catalog target and an explicit selection outcome. */
    private openCatalogInstall;
    /**
     * Check the typed spec, then install it. The Host reads what the spec
     * names first; a refused spec returns to the field with the reason, an
     * accepted one becomes the subject the next screens show while pnpm runs.
     */
    private runInstall;
    /**
     * Hand the checked spec to the Host and settle the dialog from its answer.
     * `approvedBuilds` names the pending install scripts the person allowed;
     * the Host saves that permission for this profile before pnpm runs.
     */
    private startInstall;
    /** A recovery call shares the Host's active result; absent results are explicitly unknown. */
    private reconcileInstall;
    private settleInstall;
    private installUncertain;
    /**
     * Allow the install scripts the failed run left pending and run the same
     * spec again. Only the failed screen with pending names offers this.
     */
    private approveBuildsAndRetry;
    /**
     * Leave the check or the failed screen for the spec at once; a Host-owned
     * run is asked to stop and its state waits for the Host's word, since
     * neither a dropped RPC nor a closed connection means pnpm has stopped.
     */
    private cancelInstall;
    /** A cancellation that overtakes installation is retried after the Host acknowledges that request. */
    private sendCancellation;
    private notifyHiddenInstall;
    /**
     * Release the tracked request and return to editing with its spec retained.
     * A cancellation notice is supplied only after the Host confirms it stopped.
     */
    private offerSpecAgain;
    /**
     * Enable the bundle the finished install added, then close the dialog and
     * mark it in the list. A refusal toasts and still closes: the list shows
     * what did not switch on.
     */
    private enableInstalled;
    /**
     * Run one action under a busy key, turn its failure into the notice, and
     * re-read the Host afterwards whatever happened.
     */
    private run;
    /**
     * Publish a change's outcome: a refused answer or a change the Host could
     * not apply throws for {@link run} to report; a change that waits for the
     * next start, that a higher layer overrides, or that the Host stopped is
     * said in passing.
     */
    private applied;
    private trackToggle;
    private finishAnalytics;
    private patch;
    private patchInstall;
}
//# sourceMappingURL=manager-store.d.ts.map